import json, requests, xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CONFIG_FILE = BASE_DIR / "feeds_config.json"

# --- CATEGORÍAS DE PESO REAL ---
AMENAZA_KINETICA = {"bombardeo", "airstrike", "missile", "misil", "explosion", "explosión", "bombing", "nuclear", "war", "guerra", "invasion", "invasión", "ataque", "attack"}
AMENAZA_SOCIAL = {"tensión", "tension", "conflict", "conflicto", "crisis", "alert", "alerta", "protest", "huelga", "manifestación"}

def calcular_score_real(texto, old_score):
    texto = texto.lower()
    
    # 1. Detectamos presencia de lenguaje de combate
    hits_kineticos = [w for w in AMENAZA_KINETICA if w in texto]
    hits_sociales = [w for w in AMENAZA_SOCIAL if w in texto]
    
    # 2. Lógica de Techo (Filtro Anti-Basura)
    if not hits_kineticos:
        # Si solo hay "ruido" social (España), el score máximo es 40
        score = 15 + (len(set(hits_sociales)) * 5)
        score = min(score, 40)
    else:
        # Si hay bombas (Irán), el score base salta a 70 + impacto
        score = 70 + (len(set(hits_kineticos)) * 10)
    
    # 3. Factor de Enfriamiento (Decay)
    if score < old_score:
        score = old_score * 0.75 # Bajada rápida si la noticia desaparece
        
    return max(10, min(98, int(score)))

def scan():
    DATA_DIR.mkdir(exist_ok=True)
    if not CONFIG_FILE.exists(): return
    
    with open(CONFIG_FILE, 'r') as f: config = json.load(f)
    headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) Chrome/122.0.0.0'}

    print(f"--- S.I.E.G. CRITICAL SCAN | {datetime.now().strftime('%H:%M')} ---")

    for region, urls in config.items():
        corpus = ""
        filename = f"geoint_{region.lower().replace(' ', '_')}.json"
        
        try:
            with open(DATA_DIR / filename, 'r') as f: old = json.load(f)['score']
        except: old = 20

        for url in urls:
            try:
                r = requests.get(url, headers=headers, timeout=10)
                root = ET.fromstring(r.content)
                for item in root.findall('.//item')[:15]:
                    t = item.find('title').text or ""
                    d = item.find('description').text if item.find('description') is not None else ""
                    corpus += f" {t} {d}"
            except: continue
        
        score = calcular_score_real(corpus, old)
        with open(DATA_DIR / filename, 'w') as f: json.dump({"score": score}, f)
        
        status = "🔥 CRÍTICO" if score > 70 else "⚖️ ESTABLE"
        print(f"[{status}] {region:15} | Score: {score}%")

if __name__ == "__main__":
    scan()
